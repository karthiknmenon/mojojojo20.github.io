# mojojojo20.github.io
A one page design resume designed using HTML, CSS, Bootstrap and other stylesheets. 
